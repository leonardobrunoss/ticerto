__author__ = 'Jocelyn Delalande'
__email__ = 'jdelalande@oasiswork.fr'
__version__ = '0.1.0'
